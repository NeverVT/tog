﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterArmor : MonoBehaviour
{
    public Sprite[] armors;

    public GameObject armorObj;
    public GameObject icon;
    public int defense;
    public string traitOne;
    public string traitTwo;
    public string traitThree;
}
