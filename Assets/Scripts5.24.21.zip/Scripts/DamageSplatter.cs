﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageSplatter : MonoBehaviour
{
    public Sprite[] splatters;
    

}
