﻿using UnityEngine;
using System.Collections;

public class LevelText : MonoBehaviour
{
    void Update()
    {
        //this.GetComponent<TextMesh>().text = Character.level.ToString();
    }
}
