﻿using UnityEngine;
using System.Collections;

public class ExpText : MonoBehaviour
{ 
    void Update()
    {
        //this.GetComponent<TextMesh>().text = Character.currentExp.ToString() + "/" + Character.neededExp.ToString();
    }
}
