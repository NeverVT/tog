﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillControl : MonoBehaviour
{
    public static SkillControl skillControl;

    public static bool bloodlust = false;
    public static bool vanish = false;
    public static bool overpowered = false;
    public static bool sacrifice = false;
    public static bool execute = false;
    public static bool blink = false;
    public static bool powderKeg = false;
    public static bool hexBall = false;
    public static int doubleShot = 0;
    public static bool bomb = false;
    public static bool dragonShot = false;
    public static bool bomberShot = false;
    public static bool smite = false;
    public static bool targeted = false;
    public static bool calculated = false;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
